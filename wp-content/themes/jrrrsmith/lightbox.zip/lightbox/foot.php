	<script src="<?php bloginfo('template_url');?>/assets/js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url');?>/html5lightbox/html5lightbox.js"></script>
	<script src="<?php bloginfo('template_url');?>/assets/js/main.js"></script>
	<?php wp_footer(); ?>
</body>
</html>
